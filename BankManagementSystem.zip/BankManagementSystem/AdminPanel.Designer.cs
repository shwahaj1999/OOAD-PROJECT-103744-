﻿namespace BankManagementSystem
{
    partial class AdminPanel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.metroTabControl1 = new MetroFramework.Controls.MetroTabControl();
            this.metroTabPage2 = new MetroFramework.Controls.MetroTabPage();
            this.metroPanel1 = new MetroFramework.Controls.MetroPanel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.metroTile1 = new MetroFramework.Controls.MetroTile();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.metroTabPage3 = new MetroFramework.Controls.MetroTabPage();
            this.metroPanel2 = new MetroFramework.Controls.MetroPanel();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.metroTile2 = new MetroFramework.Controls.MetroTile();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.metroTabPage4 = new MetroFramework.Controls.MetroTabPage();
            this.metroPanel3 = new MetroFramework.Controls.MetroPanel();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.metroTile3 = new MetroFramework.Controls.MetroTile();
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel6 = new MetroFramework.Controls.MetroLabel();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.metroTabPage5 = new MetroFramework.Controls.MetroTabPage();
            this.monthCalendar2 = new System.Windows.Forms.MonthCalendar();
            this.metroLabel9 = new MetroFramework.Controls.MetroLabel();
            this.monthCalendar1 = new System.Windows.Forms.MonthCalendar();
            this.metroPanel4 = new MetroFramework.Controls.MetroPanel();
            this.dataGridView4 = new System.Windows.Forms.DataGridView();
            this.metroTile4 = new MetroFramework.Controls.MetroTile();
            this.metroLabel7 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel8 = new MetroFramework.Controls.MetroLabel();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.metroTabPage6 = new MetroFramework.Controls.MetroTabPage();
            this.metroLabel10 = new MetroFramework.Controls.MetroLabel();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.metroTile5 = new MetroFramework.Controls.MetroTile();
            this.monthCalendar4 = new System.Windows.Forms.MonthCalendar();
            this.metroPanel5 = new MetroFramework.Controls.MetroPanel();
            this.dataGridView5 = new System.Windows.Forms.DataGridView();
            this.metroLabel11 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel12 = new MetroFramework.Controls.MetroLabel();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.metroTabPage7 = new MetroFramework.Controls.MetroTabPage();
            this.metroPanel7 = new MetroFramework.Controls.MetroPanel();
            this.metroTile7 = new MetroFramework.Controls.MetroTile();
            this.metroCheckBox2 = new MetroFramework.Controls.MetroCheckBox();
            this.metroLabel20 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel21 = new MetroFramework.Controls.MetroLabel();
            this.metroComboBox2 = new MetroFramework.Controls.MetroComboBox();
            this.metroLabel23 = new MetroFramework.Controls.MetroLabel();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.metroLabel25 = new MetroFramework.Controls.MetroLabel();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.metroLabel26 = new MetroFramework.Controls.MetroLabel();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.metroLabel27 = new MetroFramework.Controls.MetroLabel();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.metroLabel28 = new MetroFramework.Controls.MetroLabel();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.metroLabel29 = new MetroFramework.Controls.MetroLabel();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.metroLabel30 = new MetroFramework.Controls.MetroLabel();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.metroPanel6 = new MetroFramework.Controls.MetroPanel();
            this.metroTile6 = new MetroFramework.Controls.MetroTile();
            this.metroCheckBox1 = new MetroFramework.Controls.MetroCheckBox();
            this.metroLabel19 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel18 = new MetroFramework.Controls.MetroLabel();
            this.metroComboBox1 = new MetroFramework.Controls.MetroComboBox();
            this.metroLabel17 = new MetroFramework.Controls.MetroLabel();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.metroLabel16 = new MetroFramework.Controls.MetroLabel();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.metroLabel15 = new MetroFramework.Controls.MetroLabel();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.metroLabel14 = new MetroFramework.Controls.MetroLabel();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.metroLabel13 = new MetroFramework.Controls.MetroLabel();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.metroLabel22 = new MetroFramework.Controls.MetroLabel();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.metroLabel24 = new MetroFramework.Controls.MetroLabel();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.metroTabPage8 = new MetroFramework.Controls.MetroTabPage();
            this.panel1 = new System.Windows.Forms.Panel();
            this.metroTile10 = new MetroFramework.Controls.MetroTile();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox31 = new System.Windows.Forms.TextBox();
            this.metroLabel40 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel41 = new MetroFramework.Controls.MetroLabel();
            this.textBox32 = new System.Windows.Forms.TextBox();
            this.metroLabel42 = new MetroFramework.Controls.MetroLabel();
            this.textBox33 = new System.Windows.Forms.TextBox();
            this.metroPanel8 = new MetroFramework.Controls.MetroPanel();
            this.metroTile11 = new MetroFramework.Controls.MetroTile();
            this.metroTile8 = new MetroFramework.Controls.MetroTile();
            this.metroCheckBox3 = new MetroFramework.Controls.MetroCheckBox();
            this.metroLabel31 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel32 = new MetroFramework.Controls.MetroLabel();
            this.metroComboBox3 = new MetroFramework.Controls.MetroComboBox();
            this.metroLabel33 = new MetroFramework.Controls.MetroLabel();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.metroLabel34 = new MetroFramework.Controls.MetroLabel();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.metroLabel36 = new MetroFramework.Controls.MetroLabel();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.metroLabel37 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel38 = new MetroFramework.Controls.MetroLabel();
            this.textBox29 = new System.Windows.Forms.TextBox();
            this.metroLabel39 = new MetroFramework.Controls.MetroLabel();
            this.textBox30 = new System.Windows.Forms.TextBox();
            this.metroTile9 = new MetroFramework.Controls.MetroTile();
            this.metroLabel43 = new MetroFramework.Controls.MetroLabel();
            this.metroTabControl1.SuspendLayout();
            this.metroTabPage2.SuspendLayout();
            this.metroPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.metroTabPage3.SuspendLayout();
            this.metroPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.metroTabPage4.SuspendLayout();
            this.metroPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            this.metroTabPage5.SuspendLayout();
            this.metroPanel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).BeginInit();
            this.metroTabPage6.SuspendLayout();
            this.metroPanel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).BeginInit();
            this.metroTabPage7.SuspendLayout();
            this.metroPanel7.SuspendLayout();
            this.metroPanel6.SuspendLayout();
            this.metroTabPage8.SuspendLayout();
            this.panel1.SuspendLayout();
            this.metroPanel8.SuspendLayout();
            this.SuspendLayout();
            // 
            // metroTabControl1
            // 
            this.metroTabControl1.Controls.Add(this.metroTabPage2);
            this.metroTabControl1.Controls.Add(this.metroTabPage3);
            this.metroTabControl1.Controls.Add(this.metroTabPage4);
            this.metroTabControl1.Controls.Add(this.metroTabPage5);
            this.metroTabControl1.Controls.Add(this.metroTabPage6);
            this.metroTabControl1.Controls.Add(this.metroTabPage7);
            this.metroTabControl1.Controls.Add(this.metroTabPage8);
            this.metroTabControl1.FontWeight = MetroFramework.MetroTabControlWeight.Bold;
            this.metroTabControl1.Location = new System.Drawing.Point(23, 63);
            this.metroTabControl1.Name = "metroTabControl1";
            this.metroTabControl1.SelectedIndex = 6;
            this.metroTabControl1.Size = new System.Drawing.Size(1347, 747);
            this.metroTabControl1.TabIndex = 16;
            this.metroTabControl1.UseSelectable = true;
            // 
            // metroTabPage2
            // 
            this.metroTabPage2.Controls.Add(this.metroPanel1);
            this.metroTabPage2.Controls.Add(this.metroTile1);
            this.metroTabPage2.Controls.Add(this.metroLabel2);
            this.metroTabPage2.Controls.Add(this.metroLabel1);
            this.metroTabPage2.Controls.Add(this.textBox2);
            this.metroTabPage2.Controls.Add(this.textBox1);
            this.metroTabPage2.HorizontalScrollbarBarColor = true;
            this.metroTabPage2.HorizontalScrollbarHighlightOnWheel = false;
            this.metroTabPage2.HorizontalScrollbarSize = 10;
            this.metroTabPage2.Location = new System.Drawing.Point(4, 38);
            this.metroTabPage2.Name = "metroTabPage2";
            this.metroTabPage2.Size = new System.Drawing.Size(1339, 705);
            this.metroTabPage2.TabIndex = 1;
            this.metroTabPage2.Text = "|    Cash Deposit    |";
            this.metroTabPage2.VerticalScrollbarBarColor = true;
            this.metroTabPage2.VerticalScrollbarHighlightOnWheel = false;
            this.metroTabPage2.VerticalScrollbarSize = 10;
            // 
            // metroPanel1
            // 
            this.metroPanel1.Controls.Add(this.dataGridView1);
            this.metroPanel1.HorizontalScrollbarBarColor = true;
            this.metroPanel1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel1.HorizontalScrollbarSize = 10;
            this.metroPanel1.Location = new System.Drawing.Point(66, 82);
            this.metroPanel1.Name = "metroPanel1";
            this.metroPanel1.Size = new System.Drawing.Size(1129, 524);
            this.metroPanel1.TabIndex = 7;
            this.metroPanel1.VerticalScrollbarBarColor = true;
            this.metroPanel1.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel1.VerticalScrollbarSize = 10;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(42, 59);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(1048, 425);
            this.dataGridView1.TabIndex = 2;
            // 
            // metroTile1
            // 
            this.metroTile1.ActiveControl = null;
            this.metroTile1.Location = new System.Drawing.Point(540, 42);
            this.metroTile1.Name = "metroTile1";
            this.metroTile1.Size = new System.Drawing.Size(75, 23);
            this.metroTile1.TabIndex = 6;
            this.metroTile1.Text = "Deposit";
            this.metroTile1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.metroTile1.UseSelectable = true;
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.Location = new System.Drawing.Point(304, 20);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(56, 19);
            this.metroLabel2.TabIndex = 5;
            this.metroLabel2.Text = "Amount";
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(66, 20);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(109, 19);
            this.metroLabel1.TabIndex = 4;
            this.metroLabel1.Text = "Account Number";
            this.metroLabel1.Click += new System.EventHandler(this.metroLabel1_Click);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(304, 42);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(172, 20);
            this.textBox2.TabIndex = 3;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(66, 42);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(172, 20);
            this.textBox1.TabIndex = 2;
            // 
            // metroTabPage3
            // 
            this.metroTabPage3.Controls.Add(this.metroPanel2);
            this.metroTabPage3.Controls.Add(this.metroTile2);
            this.metroTabPage3.Controls.Add(this.metroLabel3);
            this.metroTabPage3.Controls.Add(this.metroLabel4);
            this.metroTabPage3.Controls.Add(this.textBox3);
            this.metroTabPage3.Controls.Add(this.textBox4);
            this.metroTabPage3.HorizontalScrollbarBarColor = true;
            this.metroTabPage3.HorizontalScrollbarHighlightOnWheel = false;
            this.metroTabPage3.HorizontalScrollbarSize = 10;
            this.metroTabPage3.Location = new System.Drawing.Point(4, 38);
            this.metroTabPage3.Name = "metroTabPage3";
            this.metroTabPage3.Size = new System.Drawing.Size(1339, 705);
            this.metroTabPage3.TabIndex = 2;
            this.metroTabPage3.Text = "|    Cash WithDrawal    |";
            this.metroTabPage3.VerticalScrollbarBarColor = true;
            this.metroTabPage3.VerticalScrollbarHighlightOnWheel = false;
            this.metroTabPage3.VerticalScrollbarSize = 10;
            // 
            // metroPanel2
            // 
            this.metroPanel2.Controls.Add(this.dataGridView2);
            this.metroPanel2.HorizontalScrollbarBarColor = true;
            this.metroPanel2.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel2.HorizontalScrollbarSize = 10;
            this.metroPanel2.Location = new System.Drawing.Point(105, 95);
            this.metroPanel2.Name = "metroPanel2";
            this.metroPanel2.Size = new System.Drawing.Size(1129, 524);
            this.metroPanel2.TabIndex = 13;
            this.metroPanel2.VerticalScrollbarBarColor = true;
            this.metroPanel2.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel2.VerticalScrollbarSize = 10;
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(42, 59);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(1048, 425);
            this.dataGridView2.TabIndex = 2;
            // 
            // metroTile2
            // 
            this.metroTile2.ActiveControl = null;
            this.metroTile2.Location = new System.Drawing.Point(579, 55);
            this.metroTile2.Name = "metroTile2";
            this.metroTile2.Size = new System.Drawing.Size(109, 23);
            this.metroTile2.TabIndex = 12;
            this.metroTile2.Text = "WithDrawal";
            this.metroTile2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.metroTile2.UseSelectable = true;
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.Location = new System.Drawing.Point(343, 33);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(56, 19);
            this.metroLabel3.TabIndex = 11;
            this.metroLabel3.Text = "Amount";
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.Location = new System.Drawing.Point(105, 33);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(109, 19);
            this.metroLabel4.TabIndex = 10;
            this.metroLabel4.Text = "Account Number";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(343, 55);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(172, 20);
            this.textBox3.TabIndex = 9;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(105, 55);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(172, 20);
            this.textBox4.TabIndex = 8;
            // 
            // metroTabPage4
            // 
            this.metroTabPage4.Controls.Add(this.metroPanel3);
            this.metroTabPage4.Controls.Add(this.metroTile3);
            this.metroTabPage4.Controls.Add(this.metroLabel5);
            this.metroTabPage4.Controls.Add(this.metroLabel6);
            this.metroTabPage4.Controls.Add(this.textBox5);
            this.metroTabPage4.Controls.Add(this.textBox6);
            this.metroTabPage4.HorizontalScrollbarBarColor = true;
            this.metroTabPage4.HorizontalScrollbarHighlightOnWheel = false;
            this.metroTabPage4.HorizontalScrollbarSize = 10;
            this.metroTabPage4.Location = new System.Drawing.Point(4, 38);
            this.metroTabPage4.Name = "metroTabPage4";
            this.metroTabPage4.Size = new System.Drawing.Size(1339, 705);
            this.metroTabPage4.TabIndex = 3;
            this.metroTabPage4.Text = "|    Balance Enquiry    |";
            this.metroTabPage4.VerticalScrollbarBarColor = true;
            this.metroTabPage4.VerticalScrollbarHighlightOnWheel = false;
            this.metroTabPage4.VerticalScrollbarSize = 10;
            // 
            // metroPanel3
            // 
            this.metroPanel3.Controls.Add(this.dataGridView3);
            this.metroPanel3.HorizontalScrollbarBarColor = true;
            this.metroPanel3.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel3.HorizontalScrollbarSize = 10;
            this.metroPanel3.Location = new System.Drawing.Point(105, 95);
            this.metroPanel3.Name = "metroPanel3";
            this.metroPanel3.Size = new System.Drawing.Size(1129, 524);
            this.metroPanel3.TabIndex = 13;
            this.metroPanel3.VerticalScrollbarBarColor = true;
            this.metroPanel3.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel3.VerticalScrollbarSize = 10;
            // 
            // dataGridView3
            // 
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Location = new System.Drawing.Point(42, 59);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.Size = new System.Drawing.Size(1048, 425);
            this.dataGridView3.TabIndex = 2;
            // 
            // metroTile3
            // 
            this.metroTile3.ActiveControl = null;
            this.metroTile3.Location = new System.Drawing.Point(579, 55);
            this.metroTile3.Name = "metroTile3";
            this.metroTile3.Size = new System.Drawing.Size(75, 23);
            this.metroTile3.TabIndex = 12;
            this.metroTile3.Text = "Deposit";
            this.metroTile3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.metroTile3.UseSelectable = true;
            // 
            // metroLabel5
            // 
            this.metroLabel5.AutoSize = true;
            this.metroLabel5.Location = new System.Drawing.Point(343, 33);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(82, 19);
            this.metroLabel5.TabIndex = 11;
            this.metroLabel5.Text = "Customer ID";
            // 
            // metroLabel6
            // 
            this.metroLabel6.AutoSize = true;
            this.metroLabel6.Location = new System.Drawing.Point(105, 33);
            this.metroLabel6.Name = "metroLabel6";
            this.metroLabel6.Size = new System.Drawing.Size(109, 19);
            this.metroLabel6.TabIndex = 10;
            this.metroLabel6.Text = "Account Number";
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(343, 55);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(172, 20);
            this.textBox5.TabIndex = 9;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(105, 55);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(172, 20);
            this.textBox6.TabIndex = 8;
            // 
            // metroTabPage5
            // 
            this.metroTabPage5.Controls.Add(this.monthCalendar2);
            this.metroTabPage5.Controls.Add(this.metroLabel9);
            this.metroTabPage5.Controls.Add(this.monthCalendar1);
            this.metroTabPage5.Controls.Add(this.metroPanel4);
            this.metroTabPage5.Controls.Add(this.metroTile4);
            this.metroTabPage5.Controls.Add(this.metroLabel7);
            this.metroTabPage5.Controls.Add(this.metroLabel8);
            this.metroTabPage5.Controls.Add(this.textBox8);
            this.metroTabPage5.HorizontalScrollbarBarColor = true;
            this.metroTabPage5.HorizontalScrollbarHighlightOnWheel = false;
            this.metroTabPage5.HorizontalScrollbarSize = 10;
            this.metroTabPage5.Location = new System.Drawing.Point(4, 38);
            this.metroTabPage5.Name = "metroTabPage5";
            this.metroTabPage5.Size = new System.Drawing.Size(1339, 705);
            this.metroTabPage5.TabIndex = 4;
            this.metroTabPage5.Text = "|     Reports    |";
            this.metroTabPage5.VerticalScrollbarBarColor = true;
            this.metroTabPage5.VerticalScrollbarHighlightOnWheel = false;
            this.metroTabPage5.VerticalScrollbarSize = 10;
            // 
            // monthCalendar2
            // 
            this.monthCalendar2.Location = new System.Drawing.Point(592, 55);
            this.monthCalendar2.Name = "monthCalendar2";
            this.monthCalendar2.TabIndex = 16;
            // 
            // metroLabel9
            // 
            this.metroLabel9.AutoSize = true;
            this.metroLabel9.Location = new System.Drawing.Point(592, 33);
            this.metroLabel9.Name = "metroLabel9";
            this.metroLabel9.Size = new System.Drawing.Size(79, 19);
            this.metroLabel9.TabIndex = 15;
            this.metroLabel9.Text = "End Date To";
            // 
            // monthCalendar1
            // 
            this.monthCalendar1.Location = new System.Drawing.Point(343, 55);
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.TabIndex = 14;
            // 
            // metroPanel4
            // 
            this.metroPanel4.Controls.Add(this.dataGridView4);
            this.metroPanel4.HorizontalScrollbarBarColor = true;
            this.metroPanel4.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel4.HorizontalScrollbarSize = 10;
            this.metroPanel4.Location = new System.Drawing.Point(118, 229);
            this.metroPanel4.Name = "metroPanel4";
            this.metroPanel4.Size = new System.Drawing.Size(1129, 524);
            this.metroPanel4.TabIndex = 13;
            this.metroPanel4.VerticalScrollbarBarColor = true;
            this.metroPanel4.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel4.VerticalScrollbarSize = 10;
            // 
            // dataGridView4
            // 
            this.dataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView4.Location = new System.Drawing.Point(42, 59);
            this.dataGridView4.Name = "dataGridView4";
            this.dataGridView4.Size = new System.Drawing.Size(1048, 425);
            this.dataGridView4.TabIndex = 2;
            // 
            // metroTile4
            // 
            this.metroTile4.ActiveControl = null;
            this.metroTile4.Location = new System.Drawing.Point(856, 55);
            this.metroTile4.Name = "metroTile4";
            this.metroTile4.Size = new System.Drawing.Size(127, 23);
            this.metroTile4.TabIndex = 12;
            this.metroTile4.Text = "Genrate Reports";
            this.metroTile4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.metroTile4.UseSelectable = true;
            // 
            // metroLabel7
            // 
            this.metroLabel7.AutoSize = true;
            this.metroLabel7.Location = new System.Drawing.Point(343, 33);
            this.metroLabel7.Name = "metroLabel7";
            this.metroLabel7.Size = new System.Drawing.Size(104, 19);
            this.metroLabel7.TabIndex = 11;
            this.metroLabel7.Text = "Start Date From";
            // 
            // metroLabel8
            // 
            this.metroLabel8.AutoSize = true;
            this.metroLabel8.Location = new System.Drawing.Point(105, 33);
            this.metroLabel8.Name = "metroLabel8";
            this.metroLabel8.Size = new System.Drawing.Size(109, 19);
            this.metroLabel8.TabIndex = 10;
            this.metroLabel8.Text = "Account Number";
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(105, 55);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(172, 20);
            this.textBox8.TabIndex = 8;
            // 
            // metroTabPage6
            // 
            this.metroTabPage6.Controls.Add(this.metroLabel10);
            this.metroTabPage6.Controls.Add(this.textBox9);
            this.metroTabPage6.Controls.Add(this.metroTile5);
            this.metroTabPage6.Controls.Add(this.monthCalendar4);
            this.metroTabPage6.Controls.Add(this.metroPanel5);
            this.metroTabPage6.Controls.Add(this.metroLabel11);
            this.metroTabPage6.Controls.Add(this.metroLabel12);
            this.metroTabPage6.Controls.Add(this.textBox7);
            this.metroTabPage6.HorizontalScrollbarBarColor = true;
            this.metroTabPage6.HorizontalScrollbarHighlightOnWheel = false;
            this.metroTabPage6.HorizontalScrollbarSize = 10;
            this.metroTabPage6.Location = new System.Drawing.Point(4, 38);
            this.metroTabPage6.Name = "metroTabPage6";
            this.metroTabPage6.Size = new System.Drawing.Size(1339, 705);
            this.metroTabPage6.TabIndex = 5;
            this.metroTabPage6.Text = "|    Check Transaction    |";
            this.metroTabPage6.VerticalScrollbarBarColor = true;
            this.metroTabPage6.VerticalScrollbarHighlightOnWheel = false;
            this.metroTabPage6.VerticalScrollbarSize = 10;
            // 
            // metroLabel10
            // 
            this.metroLabel10.AutoSize = true;
            this.metroLabel10.Location = new System.Drawing.Point(98, 78);
            this.metroLabel10.Name = "metroLabel10";
            this.metroLabel10.Size = new System.Drawing.Size(99, 19);
            this.metroLabel10.TabIndex = 26;
            this.metroLabel10.Text = "By Customer Id";
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(98, 100);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(172, 20);
            this.textBox9.TabIndex = 25;
            // 
            // metroTile5
            // 
            this.metroTile5.ActiveControl = null;
            this.metroTile5.Location = new System.Drawing.Point(596, 42);
            this.metroTile5.Name = "metroTile5";
            this.metroTile5.Size = new System.Drawing.Size(127, 23);
            this.metroTile5.TabIndex = 24;
            this.metroTile5.Text = "Show";
            this.metroTile5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.metroTile5.UseSelectable = true;
            // 
            // monthCalendar4
            // 
            this.monthCalendar4.Location = new System.Drawing.Point(336, 42);
            this.monthCalendar4.Name = "monthCalendar4";
            this.monthCalendar4.TabIndex = 21;
            // 
            // metroPanel5
            // 
            this.metroPanel5.Controls.Add(this.dataGridView5);
            this.metroPanel5.HorizontalScrollbarBarColor = true;
            this.metroPanel5.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel5.HorizontalScrollbarSize = 10;
            this.metroPanel5.Location = new System.Drawing.Point(111, 216);
            this.metroPanel5.Name = "metroPanel5";
            this.metroPanel5.Size = new System.Drawing.Size(1129, 524);
            this.metroPanel5.TabIndex = 20;
            this.metroPanel5.VerticalScrollbarBarColor = true;
            this.metroPanel5.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel5.VerticalScrollbarSize = 10;
            // 
            // dataGridView5
            // 
            this.dataGridView5.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView5.Location = new System.Drawing.Point(42, 59);
            this.dataGridView5.Name = "dataGridView5";
            this.dataGridView5.Size = new System.Drawing.Size(1048, 425);
            this.dataGridView5.TabIndex = 2;
            // 
            // metroLabel11
            // 
            this.metroLabel11.AutoSize = true;
            this.metroLabel11.Location = new System.Drawing.Point(336, 20);
            this.metroLabel11.Name = "metroLabel11";
            this.metroLabel11.Size = new System.Drawing.Size(167, 19);
            this.metroLabel11.TabIndex = 19;
            this.metroLabel11.Text = "Date Wise /Monthly /Yearly";
            // 
            // metroLabel12
            // 
            this.metroLabel12.AutoSize = true;
            this.metroLabel12.Location = new System.Drawing.Point(98, 20);
            this.metroLabel12.Name = "metroLabel12";
            this.metroLabel12.Size = new System.Drawing.Size(109, 19);
            this.metroLabel12.TabIndex = 18;
            this.metroLabel12.Text = "Account Number";
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(98, 42);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(172, 20);
            this.textBox7.TabIndex = 17;
            // 
            // metroTabPage7
            // 
            this.metroTabPage7.Controls.Add(this.metroPanel7);
            this.metroTabPage7.Controls.Add(this.metroPanel6);
            this.metroTabPage7.HorizontalScrollbarBarColor = true;
            this.metroTabPage7.HorizontalScrollbarHighlightOnWheel = false;
            this.metroTabPage7.HorizontalScrollbarSize = 10;
            this.metroTabPage7.Location = new System.Drawing.Point(4, 38);
            this.metroTabPage7.Name = "metroTabPage7";
            this.metroTabPage7.Size = new System.Drawing.Size(1339, 705);
            this.metroTabPage7.TabIndex = 6;
            this.metroTabPage7.Text = "|    User Manage    |";
            this.metroTabPage7.VerticalScrollbarBarColor = true;
            this.metroTabPage7.VerticalScrollbarHighlightOnWheel = false;
            this.metroTabPage7.VerticalScrollbarSize = 10;
            // 
            // metroPanel7
            // 
            this.metroPanel7.Controls.Add(this.metroTile7);
            this.metroPanel7.Controls.Add(this.metroCheckBox2);
            this.metroPanel7.Controls.Add(this.metroLabel20);
            this.metroPanel7.Controls.Add(this.metroLabel21);
            this.metroPanel7.Controls.Add(this.metroComboBox2);
            this.metroPanel7.Controls.Add(this.metroLabel23);
            this.metroPanel7.Controls.Add(this.textBox15);
            this.metroPanel7.Controls.Add(this.metroLabel25);
            this.metroPanel7.Controls.Add(this.textBox16);
            this.metroPanel7.Controls.Add(this.metroLabel26);
            this.metroPanel7.Controls.Add(this.textBox19);
            this.metroPanel7.Controls.Add(this.label2);
            this.metroPanel7.Controls.Add(this.metroLabel27);
            this.metroPanel7.Controls.Add(this.textBox20);
            this.metroPanel7.Controls.Add(this.metroLabel28);
            this.metroPanel7.Controls.Add(this.textBox21);
            this.metroPanel7.Controls.Add(this.metroLabel29);
            this.metroPanel7.Controls.Add(this.textBox22);
            this.metroPanel7.Controls.Add(this.metroLabel30);
            this.metroPanel7.Controls.Add(this.textBox23);
            this.metroPanel7.HorizontalScrollbarBarColor = true;
            this.metroPanel7.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel7.HorizontalScrollbarSize = 10;
            this.metroPanel7.Location = new System.Drawing.Point(762, 60);
            this.metroPanel7.Name = "metroPanel7";
            this.metroPanel7.Size = new System.Drawing.Size(425, 500);
            this.metroPanel7.TabIndex = 3;
            this.metroPanel7.VerticalScrollbarBarColor = true;
            this.metroPanel7.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel7.VerticalScrollbarSize = 10;
            // 
            // metroTile7
            // 
            this.metroTile7.ActiveControl = null;
            this.metroTile7.Location = new System.Drawing.Point(248, 433);
            this.metroTile7.Name = "metroTile7";
            this.metroTile7.Size = new System.Drawing.Size(135, 23);
            this.metroTile7.TabIndex = 50;
            this.metroTile7.Text = "Update";
            this.metroTile7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.metroTile7.UseSelectable = true;
            // 
            // metroCheckBox2
            // 
            this.metroCheckBox2.AutoSize = true;
            this.metroCheckBox2.Location = new System.Drawing.Point(50, 441);
            this.metroCheckBox2.Name = "metroCheckBox2";
            this.metroCheckBox2.Size = new System.Drawing.Size(115, 15);
            this.metroCheckBox2.TabIndex = 49;
            this.metroCheckBox2.Text = "Active /Un Active";
            this.metroCheckBox2.UseSelectable = true;
            // 
            // metroLabel20
            // 
            this.metroLabel20.AutoSize = true;
            this.metroLabel20.Location = new System.Drawing.Point(44, 419);
            this.metroLabel20.Name = "metroLabel20";
            this.metroLabel20.Size = new System.Drawing.Size(43, 19);
            this.metroLabel20.TabIndex = 48;
            this.metroLabel20.Text = "Status";
            // 
            // metroLabel21
            // 
            this.metroLabel21.AutoSize = true;
            this.metroLabel21.Location = new System.Drawing.Point(44, 365);
            this.metroLabel21.Name = "metroLabel21";
            this.metroLabel21.Size = new System.Drawing.Size(52, 19);
            this.metroLabel21.TabIndex = 47;
            this.metroLabel21.Text = "Gender";
            // 
            // metroComboBox2
            // 
            this.metroComboBox2.FormattingEnabled = true;
            this.metroComboBox2.ItemHeight = 23;
            this.metroComboBox2.Location = new System.Drawing.Point(44, 387);
            this.metroComboBox2.Name = "metroComboBox2";
            this.metroComboBox2.Size = new System.Drawing.Size(172, 29);
            this.metroComboBox2.TabIndex = 46;
            this.metroComboBox2.UseSelectable = true;
            // 
            // metroLabel23
            // 
            this.metroLabel23.AutoSize = true;
            this.metroLabel23.Location = new System.Drawing.Point(44, 319);
            this.metroLabel23.Name = "metroLabel23";
            this.metroLabel23.Size = new System.Drawing.Size(119, 19);
            this.metroLabel23.TabIndex = 45;
            this.metroLabel23.Text = "Oppening Amount";
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(44, 341);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(172, 20);
            this.textBox15.TabIndex = 44;
            // 
            // metroLabel25
            // 
            this.metroLabel25.AutoSize = true;
            this.metroLabel25.Location = new System.Drawing.Point(44, 274);
            this.metroLabel25.Name = "metroLabel25";
            this.metroLabel25.Size = new System.Drawing.Size(96, 19);
            this.metroLabel25.TabIndex = 43;
            this.metroLabel25.Text = "Annual Income";
            // 
            // textBox16
            // 
            this.textBox16.Location = new System.Drawing.Point(44, 296);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(172, 20);
            this.textBox16.TabIndex = 42;
            // 
            // metroLabel26
            // 
            this.metroLabel26.AutoSize = true;
            this.metroLabel26.Location = new System.Drawing.Point(44, 229);
            this.metroLabel26.Name = "metroLabel26";
            this.metroLabel26.Size = new System.Drawing.Size(76, 19);
            this.metroLabel26.TabIndex = 41;
            this.metroLabel26.Text = "Occupation";
            // 
            // textBox19
            // 
            this.textBox19.Location = new System.Drawing.Point(44, 251);
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(172, 20);
            this.textBox19.TabIndex = 40;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(32, 4);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(222, 31);
            this.label2.TabIndex = 39;
            this.label2.Text = "Update Account";
            // 
            // metroLabel27
            // 
            this.metroLabel27.AutoSize = true;
            this.metroLabel27.Location = new System.Drawing.Point(44, 184);
            this.metroLabel27.Name = "metroLabel27";
            this.metroLabel27.Size = new System.Drawing.Size(33, 19);
            this.metroLabel27.TabIndex = 38;
            this.metroLabel27.Text = "Age";
            // 
            // textBox20
            // 
            this.textBox20.Location = new System.Drawing.Point(44, 206);
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(172, 20);
            this.textBox20.TabIndex = 37;
            // 
            // metroLabel28
            // 
            this.metroLabel28.AutoSize = true;
            this.metroLabel28.Location = new System.Drawing.Point(44, 139);
            this.metroLabel28.Name = "metroLabel28";
            this.metroLabel28.Size = new System.Drawing.Size(66, 19);
            this.metroLabel28.TabIndex = 36;
            this.metroLabel28.Text = "Contact #";
            // 
            // textBox21
            // 
            this.textBox21.Location = new System.Drawing.Point(44, 161);
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(172, 20);
            this.textBox21.TabIndex = 35;
            // 
            // metroLabel29
            // 
            this.metroLabel29.AutoSize = true;
            this.metroLabel29.Location = new System.Drawing.Point(44, 94);
            this.metroLabel29.Name = "metroLabel29";
            this.metroLabel29.Size = new System.Drawing.Size(41, 19);
            this.metroLabel29.TabIndex = 34;
            this.metroLabel29.Text = "Email";
            // 
            // textBox22
            // 
            this.textBox22.Location = new System.Drawing.Point(44, 116);
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(172, 20);
            this.textBox22.TabIndex = 33;
            // 
            // metroLabel30
            // 
            this.metroLabel30.AutoSize = true;
            this.metroLabel30.Location = new System.Drawing.Point(44, 49);
            this.metroLabel30.Name = "metroLabel30";
            this.metroLabel30.Size = new System.Drawing.Size(45, 19);
            this.metroLabel30.TabIndex = 32;
            this.metroLabel30.Text = "Name";
            // 
            // textBox23
            // 
            this.textBox23.Location = new System.Drawing.Point(44, 71);
            this.textBox23.Name = "textBox23";
            this.textBox23.Size = new System.Drawing.Size(172, 20);
            this.textBox23.TabIndex = 31;
            // 
            // metroPanel6
            // 
            this.metroPanel6.Controls.Add(this.metroTile6);
            this.metroPanel6.Controls.Add(this.metroCheckBox1);
            this.metroPanel6.Controls.Add(this.metroLabel19);
            this.metroPanel6.Controls.Add(this.metroLabel18);
            this.metroPanel6.Controls.Add(this.metroComboBox1);
            this.metroPanel6.Controls.Add(this.metroLabel17);
            this.metroPanel6.Controls.Add(this.textBox14);
            this.metroPanel6.Controls.Add(this.metroLabel16);
            this.metroPanel6.Controls.Add(this.textBox13);
            this.metroPanel6.Controls.Add(this.metroLabel15);
            this.metroPanel6.Controls.Add(this.textBox12);
            this.metroPanel6.Controls.Add(this.label1);
            this.metroPanel6.Controls.Add(this.metroLabel14);
            this.metroPanel6.Controls.Add(this.textBox11);
            this.metroPanel6.Controls.Add(this.metroLabel13);
            this.metroPanel6.Controls.Add(this.textBox10);
            this.metroPanel6.Controls.Add(this.metroLabel22);
            this.metroPanel6.Controls.Add(this.textBox17);
            this.metroPanel6.Controls.Add(this.metroLabel24);
            this.metroPanel6.Controls.Add(this.textBox18);
            this.metroPanel6.HorizontalScrollbarBarColor = true;
            this.metroPanel6.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel6.HorizontalScrollbarSize = 10;
            this.metroPanel6.Location = new System.Drawing.Point(64, 60);
            this.metroPanel6.Name = "metroPanel6";
            this.metroPanel6.Size = new System.Drawing.Size(425, 500);
            this.metroPanel6.TabIndex = 2;
            this.metroPanel6.VerticalScrollbarBarColor = true;
            this.metroPanel6.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel6.VerticalScrollbarSize = 10;
            this.metroPanel6.Paint += new System.Windows.Forms.PaintEventHandler(this.metroPanel6_Paint);
            // 
            // metroTile6
            // 
            this.metroTile6.ActiveControl = null;
            this.metroTile6.Location = new System.Drawing.Point(248, 433);
            this.metroTile6.Name = "metroTile6";
            this.metroTile6.Size = new System.Drawing.Size(135, 23);
            this.metroTile6.TabIndex = 50;
            this.metroTile6.Text = "Create";
            this.metroTile6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.metroTile6.UseSelectable = true;
            // 
            // metroCheckBox1
            // 
            this.metroCheckBox1.AutoSize = true;
            this.metroCheckBox1.Location = new System.Drawing.Point(50, 441);
            this.metroCheckBox1.Name = "metroCheckBox1";
            this.metroCheckBox1.Size = new System.Drawing.Size(115, 15);
            this.metroCheckBox1.TabIndex = 49;
            this.metroCheckBox1.Text = "Active /Un Active";
            this.metroCheckBox1.UseSelectable = true;
            // 
            // metroLabel19
            // 
            this.metroLabel19.AutoSize = true;
            this.metroLabel19.Location = new System.Drawing.Point(44, 419);
            this.metroLabel19.Name = "metroLabel19";
            this.metroLabel19.Size = new System.Drawing.Size(43, 19);
            this.metroLabel19.TabIndex = 48;
            this.metroLabel19.Text = "Status";
            // 
            // metroLabel18
            // 
            this.metroLabel18.AutoSize = true;
            this.metroLabel18.Location = new System.Drawing.Point(44, 365);
            this.metroLabel18.Name = "metroLabel18";
            this.metroLabel18.Size = new System.Drawing.Size(52, 19);
            this.metroLabel18.TabIndex = 47;
            this.metroLabel18.Text = "Gender";
            // 
            // metroComboBox1
            // 
            this.metroComboBox1.FormattingEnabled = true;
            this.metroComboBox1.ItemHeight = 23;
            this.metroComboBox1.Location = new System.Drawing.Point(44, 387);
            this.metroComboBox1.Name = "metroComboBox1";
            this.metroComboBox1.Size = new System.Drawing.Size(172, 29);
            this.metroComboBox1.TabIndex = 46;
            this.metroComboBox1.UseSelectable = true;
            // 
            // metroLabel17
            // 
            this.metroLabel17.AutoSize = true;
            this.metroLabel17.Location = new System.Drawing.Point(44, 319);
            this.metroLabel17.Name = "metroLabel17";
            this.metroLabel17.Size = new System.Drawing.Size(119, 19);
            this.metroLabel17.TabIndex = 45;
            this.metroLabel17.Text = "Oppening Amount";
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(44, 341);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(172, 20);
            this.textBox14.TabIndex = 44;
            // 
            // metroLabel16
            // 
            this.metroLabel16.AutoSize = true;
            this.metroLabel16.Location = new System.Drawing.Point(44, 274);
            this.metroLabel16.Name = "metroLabel16";
            this.metroLabel16.Size = new System.Drawing.Size(96, 19);
            this.metroLabel16.TabIndex = 43;
            this.metroLabel16.Text = "Annual Income";
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(44, 296);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(172, 20);
            this.textBox13.TabIndex = 42;
            // 
            // metroLabel15
            // 
            this.metroLabel15.AutoSize = true;
            this.metroLabel15.Location = new System.Drawing.Point(44, 229);
            this.metroLabel15.Name = "metroLabel15";
            this.metroLabel15.Size = new System.Drawing.Size(76, 19);
            this.metroLabel15.TabIndex = 41;
            this.metroLabel15.Text = "Occupation";
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(44, 251);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(172, 20);
            this.textBox12.TabIndex = 40;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(32, 4);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(186, 31);
            this.label1.TabIndex = 39;
            this.label1.Text = "New Account";
            // 
            // metroLabel14
            // 
            this.metroLabel14.AutoSize = true;
            this.metroLabel14.Location = new System.Drawing.Point(44, 184);
            this.metroLabel14.Name = "metroLabel14";
            this.metroLabel14.Size = new System.Drawing.Size(33, 19);
            this.metroLabel14.TabIndex = 38;
            this.metroLabel14.Text = "Age";
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(44, 206);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(172, 20);
            this.textBox11.TabIndex = 37;
            // 
            // metroLabel13
            // 
            this.metroLabel13.AutoSize = true;
            this.metroLabel13.Location = new System.Drawing.Point(44, 139);
            this.metroLabel13.Name = "metroLabel13";
            this.metroLabel13.Size = new System.Drawing.Size(66, 19);
            this.metroLabel13.TabIndex = 36;
            this.metroLabel13.Text = "Contact #";
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(44, 161);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(172, 20);
            this.textBox10.TabIndex = 35;
            // 
            // metroLabel22
            // 
            this.metroLabel22.AutoSize = true;
            this.metroLabel22.Location = new System.Drawing.Point(44, 94);
            this.metroLabel22.Name = "metroLabel22";
            this.metroLabel22.Size = new System.Drawing.Size(41, 19);
            this.metroLabel22.TabIndex = 34;
            this.metroLabel22.Text = "Email";
            // 
            // textBox17
            // 
            this.textBox17.Location = new System.Drawing.Point(44, 116);
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(172, 20);
            this.textBox17.TabIndex = 33;
            // 
            // metroLabel24
            // 
            this.metroLabel24.AutoSize = true;
            this.metroLabel24.Location = new System.Drawing.Point(44, 49);
            this.metroLabel24.Name = "metroLabel24";
            this.metroLabel24.Size = new System.Drawing.Size(45, 19);
            this.metroLabel24.TabIndex = 32;
            this.metroLabel24.Text = "Name";
            // 
            // textBox18
            // 
            this.textBox18.Location = new System.Drawing.Point(44, 71);
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(172, 20);
            this.textBox18.TabIndex = 31;
            // 
            // metroTabPage8
            // 
            this.metroTabPage8.Controls.Add(this.panel1);
            this.metroTabPage8.Controls.Add(this.metroPanel8);
            this.metroTabPage8.HorizontalScrollbarBarColor = true;
            this.metroTabPage8.HorizontalScrollbarHighlightOnWheel = false;
            this.metroTabPage8.HorizontalScrollbarSize = 10;
            this.metroTabPage8.Location = new System.Drawing.Point(4, 38);
            this.metroTabPage8.Name = "metroTabPage8";
            this.metroTabPage8.Size = new System.Drawing.Size(1339, 705);
            this.metroTabPage8.TabIndex = 7;
            this.metroTabPage8.Text = "|      Update Accout     |";
            this.metroTabPage8.VerticalScrollbarBarColor = true;
            this.metroTabPage8.VerticalScrollbarHighlightOnWheel = false;
            this.metroTabPage8.VerticalScrollbarSize = 10;
            this.metroTabPage8.Click += new System.EventHandler(this.metroTabPage8_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel1.Controls.Add(this.metroTile10);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.textBox31);
            this.panel1.Controls.Add(this.metroLabel40);
            this.panel1.Controls.Add(this.metroLabel41);
            this.panel1.Controls.Add(this.textBox32);
            this.panel1.Controls.Add(this.metroLabel42);
            this.panel1.Controls.Add(this.textBox33);
            this.panel1.Location = new System.Drawing.Point(680, 115);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(289, 262);
            this.panel1.TabIndex = 58;
            // 
            // metroTile10
            // 
            this.metroTile10.ActiveControl = null;
            this.metroTile10.Location = new System.Drawing.Point(142, 225);
            this.metroTile10.Name = "metroTile10";
            this.metroTile10.Size = new System.Drawing.Size(135, 23);
            this.metroTile10.TabIndex = 58;
            this.metroTile10.Text = "Change";
            this.metroTile10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.metroTile10.UseSelectable = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.White;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(33, 28);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(251, 31);
            this.label4.TabIndex = 57;
            this.label4.Text = "Change Password\r\n";
            // 
            // textBox31
            // 
            this.textBox31.Location = new System.Drawing.Point(39, 103);
            this.textBox31.Name = "textBox31";
            this.textBox31.Size = new System.Drawing.Size(172, 20);
            this.textBox31.TabIndex = 51;
            // 
            // metroLabel40
            // 
            this.metroLabel40.AutoSize = true;
            this.metroLabel40.Location = new System.Drawing.Point(39, 81);
            this.metroLabel40.Name = "metroLabel40";
            this.metroLabel40.Size = new System.Drawing.Size(89, 19);
            this.metroLabel40.TabIndex = 52;
            this.metroLabel40.Text = "Old Password";
            // 
            // metroLabel41
            // 
            this.metroLabel41.AutoSize = true;
            this.metroLabel41.Location = new System.Drawing.Point(39, 126);
            this.metroLabel41.Name = "metroLabel41";
            this.metroLabel41.Size = new System.Drawing.Size(97, 19);
            this.metroLabel41.TabIndex = 54;
            this.metroLabel41.Text = "New  Password";
            // 
            // textBox32
            // 
            this.textBox32.Location = new System.Drawing.Point(39, 148);
            this.textBox32.Name = "textBox32";
            this.textBox32.Size = new System.Drawing.Size(172, 20);
            this.textBox32.TabIndex = 53;
            // 
            // metroLabel42
            // 
            this.metroLabel42.AutoSize = true;
            this.metroLabel42.Location = new System.Drawing.Point(39, 171);
            this.metroLabel42.Name = "metroLabel42";
            this.metroLabel42.Size = new System.Drawing.Size(120, 19);
            this.metroLabel42.TabIndex = 56;
            this.metroLabel42.Text = "Conform Password";
            // 
            // textBox33
            // 
            this.textBox33.Location = new System.Drawing.Point(39, 193);
            this.textBox33.Name = "textBox33";
            this.textBox33.Size = new System.Drawing.Size(172, 20);
            this.textBox33.TabIndex = 55;
            // 
            // metroPanel8
            // 
            this.metroPanel8.Controls.Add(this.metroTile11);
            this.metroPanel8.Controls.Add(this.metroTile8);
            this.metroPanel8.Controls.Add(this.metroCheckBox3);
            this.metroPanel8.Controls.Add(this.metroLabel31);
            this.metroPanel8.Controls.Add(this.metroLabel32);
            this.metroPanel8.Controls.Add(this.metroComboBox3);
            this.metroPanel8.Controls.Add(this.metroLabel33);
            this.metroPanel8.Controls.Add(this.textBox24);
            this.metroPanel8.Controls.Add(this.metroLabel34);
            this.metroPanel8.Controls.Add(this.textBox25);
            this.metroPanel8.Controls.Add(this.textBox26);
            this.metroPanel8.Controls.Add(this.label3);
            this.metroPanel8.Controls.Add(this.metroLabel36);
            this.metroPanel8.Controls.Add(this.textBox27);
            this.metroPanel8.Controls.Add(this.metroLabel37);
            this.metroPanel8.Controls.Add(this.metroLabel38);
            this.metroPanel8.Controls.Add(this.textBox29);
            this.metroPanel8.Controls.Add(this.metroLabel39);
            this.metroPanel8.Controls.Add(this.textBox30);
            this.metroPanel8.HorizontalScrollbarBarColor = true;
            this.metroPanel8.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel8.HorizontalScrollbarSize = 10;
            this.metroPanel8.Location = new System.Drawing.Point(81, 115);
            this.metroPanel8.Name = "metroPanel8";
            this.metroPanel8.Size = new System.Drawing.Size(406, 547);
            this.metroPanel8.TabIndex = 4;
            this.metroPanel8.VerticalScrollbarBarColor = true;
            this.metroPanel8.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel8.VerticalScrollbarSize = 10;
            // 
            // metroTile11
            // 
            this.metroTile11.ActiveControl = null;
            this.metroTile11.Location = new System.Drawing.Point(268, 17);
            this.metroTile11.Name = "metroTile11";
            this.metroTile11.Size = new System.Drawing.Size(135, 23);
            this.metroTile11.TabIndex = 53;
            this.metroTile11.Text = "Get Info";
            this.metroTile11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.metroTile11.UseSelectable = true;
            this.metroTile11.Click += new System.EventHandler(this.metroTile11_Click);
            // 
            // metroTile8
            // 
            this.metroTile8.ActiveControl = null;
            this.metroTile8.Location = new System.Drawing.Point(47, 468);
            this.metroTile8.Name = "metroTile8";
            this.metroTile8.Size = new System.Drawing.Size(135, 23);
            this.metroTile8.TabIndex = 50;
            this.metroTile8.Text = "Update";
            this.metroTile8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.metroTile8.UseSelectable = true;
            // 
            // metroCheckBox3
            // 
            this.metroCheckBox3.AutoSize = true;
            this.metroCheckBox3.Location = new System.Drawing.Point(56, 428);
            this.metroCheckBox3.Name = "metroCheckBox3";
            this.metroCheckBox3.Size = new System.Drawing.Size(115, 15);
            this.metroCheckBox3.TabIndex = 49;
            this.metroCheckBox3.Text = "Active /Un Active";
            this.metroCheckBox3.UseSelectable = true;
            // 
            // metroLabel31
            // 
            this.metroLabel31.AutoSize = true;
            this.metroLabel31.Location = new System.Drawing.Point(56, 406);
            this.metroLabel31.Name = "metroLabel31";
            this.metroLabel31.Size = new System.Drawing.Size(43, 19);
            this.metroLabel31.TabIndex = 48;
            this.metroLabel31.Text = "Status";
            // 
            // metroLabel32
            // 
            this.metroLabel32.AutoSize = true;
            this.metroLabel32.Location = new System.Drawing.Point(43, 233);
            this.metroLabel32.Name = "metroLabel32";
            this.metroLabel32.Size = new System.Drawing.Size(52, 19);
            this.metroLabel32.TabIndex = 47;
            this.metroLabel32.Text = "Gender";
            // 
            // metroComboBox3
            // 
            this.metroComboBox3.FormattingEnabled = true;
            this.metroComboBox3.ItemHeight = 23;
            this.metroComboBox3.Items.AddRange(new object[] {
            "MALE",
            "FEMALE"});
            this.metroComboBox3.Location = new System.Drawing.Point(44, 255);
            this.metroComboBox3.Name = "metroComboBox3";
            this.metroComboBox3.Size = new System.Drawing.Size(172, 29);
            this.metroComboBox3.TabIndex = 46;
            this.metroComboBox3.UseSelectable = true;
            // 
            // metroLabel33
            // 
            this.metroLabel33.AutoSize = true;
            this.metroLabel33.Location = new System.Drawing.Point(47, 350);
            this.metroLabel33.Name = "metroLabel33";
            this.metroLabel33.Size = new System.Drawing.Size(56, 19);
            this.metroLabel33.TabIndex = 45;
            this.metroLabel33.Text = "Address";
            // 
            // textBox24
            // 
            this.textBox24.Location = new System.Drawing.Point(44, 71);
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new System.Drawing.Size(172, 20);
            this.textBox24.TabIndex = 44;
            this.textBox24.TextChanged += new System.EventHandler(this.textBox24_TextChanged);
            // 
            // metroLabel34
            // 
            this.metroLabel34.AutoSize = true;
            this.metroLabel34.Location = new System.Drawing.Point(44, 305);
            this.metroLabel34.Name = "metroLabel34";
            this.metroLabel34.Size = new System.Drawing.Size(84, 19);
            this.metroLabel34.TabIndex = 43;
            this.metroLabel34.Text = "Date of Birth";
            // 
            // textBox25
            // 
            this.textBox25.Location = new System.Drawing.Point(44, 116);
            this.textBox25.Name = "textBox25";
            this.textBox25.Size = new System.Drawing.Size(172, 20);
            this.textBox25.TabIndex = 42;
            // 
            // textBox26
            // 
            this.textBox26.Location = new System.Drawing.Point(44, 161);
            this.textBox26.Name = "textBox26";
            this.textBox26.Size = new System.Drawing.Size(172, 20);
            this.textBox26.TabIndex = 40;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.White;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(23, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(222, 31);
            this.label3.TabIndex = 39;
            this.label3.Text = "Update Account";
            // 
            // metroLabel36
            // 
            this.metroLabel36.AutoSize = true;
            this.metroLabel36.Location = new System.Drawing.Point(44, 184);
            this.metroLabel36.Name = "metroLabel36";
            this.metroLabel36.Size = new System.Drawing.Size(33, 19);
            this.metroLabel36.TabIndex = 38;
            this.metroLabel36.Text = "Age";
            // 
            // textBox27
            // 
            this.textBox27.Location = new System.Drawing.Point(44, 206);
            this.textBox27.Name = "textBox27";
            this.textBox27.Size = new System.Drawing.Size(172, 20);
            this.textBox27.TabIndex = 37;
            // 
            // metroLabel37
            // 
            this.metroLabel37.AutoSize = true;
            this.metroLabel37.Location = new System.Drawing.Point(44, 139);
            this.metroLabel37.Name = "metroLabel37";
            this.metroLabel37.Size = new System.Drawing.Size(66, 19);
            this.metroLabel37.TabIndex = 36;
            this.metroLabel37.Text = "Contact #";
            // 
            // metroLabel38
            // 
            this.metroLabel38.AutoSize = true;
            this.metroLabel38.Location = new System.Drawing.Point(44, 94);
            this.metroLabel38.Name = "metroLabel38";
            this.metroLabel38.Size = new System.Drawing.Size(41, 19);
            this.metroLabel38.TabIndex = 34;
            this.metroLabel38.Text = "Email";
            // 
            // textBox29
            // 
            this.textBox29.Location = new System.Drawing.Point(44, 327);
            this.textBox29.Name = "textBox29";
            this.textBox29.Size = new System.Drawing.Size(172, 20);
            this.textBox29.TabIndex = 33;
            // 
            // metroLabel39
            // 
            this.metroLabel39.AutoSize = true;
            this.metroLabel39.Location = new System.Drawing.Point(44, 49);
            this.metroLabel39.Name = "metroLabel39";
            this.metroLabel39.Size = new System.Drawing.Size(45, 19);
            this.metroLabel39.TabIndex = 32;
            this.metroLabel39.Text = "Name";
            // 
            // textBox30
            // 
            this.textBox30.Location = new System.Drawing.Point(47, 372);
            this.textBox30.Name = "textBox30";
            this.textBox30.Size = new System.Drawing.Size(172, 20);
            this.textBox30.TabIndex = 31;
            // 
            // metroTile9
            // 
            this.metroTile9.ActiveControl = null;
            this.metroTile9.Location = new System.Drawing.Point(1295, 8);
            this.metroTile9.Name = "metroTile9";
            this.metroTile9.Size = new System.Drawing.Size(75, 23);
            this.metroTile9.TabIndex = 17;
            this.metroTile9.Text = "Logout";
            this.metroTile9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.metroTile9.UseSelectable = true;
            this.metroTile9.Click += new System.EventHandler(this.metroTile9_Click);
            // 
            // metroLabel43
            // 
            this.metroLabel43.AutoSize = true;
            this.metroLabel43.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel43.Location = new System.Drawing.Point(304, 26);
            this.metroLabel43.Name = "metroLabel43";
            this.metroLabel43.Size = new System.Drawing.Size(17, 25);
            this.metroLabel43.Style = MetroFramework.MetroColorStyle.Black;
            this.metroLabel43.TabIndex = 18;
            this.metroLabel43.Text = "(";
            // 
            // AdminPanel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1369, 780);
            this.Controls.Add(this.metroLabel43);
            this.Controls.Add(this.metroTile9);
            this.Controls.Add(this.metroTabControl1);
            this.Name = "AdminPanel";
            this.Text = "Bank Management System ";
            this.Load += new System.EventHandler(this.Admin_Load);
            this.metroTabControl1.ResumeLayout(false);
            this.metroTabPage2.ResumeLayout(false);
            this.metroTabPage2.PerformLayout();
            this.metroPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.metroTabPage3.ResumeLayout(false);
            this.metroTabPage3.PerformLayout();
            this.metroPanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.metroTabPage4.ResumeLayout(false);
            this.metroTabPage4.PerformLayout();
            this.metroPanel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            this.metroTabPage5.ResumeLayout(false);
            this.metroTabPage5.PerformLayout();
            this.metroPanel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).EndInit();
            this.metroTabPage6.ResumeLayout(false);
            this.metroTabPage6.PerformLayout();
            this.metroPanel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).EndInit();
            this.metroTabPage7.ResumeLayout(false);
            this.metroPanel7.ResumeLayout(false);
            this.metroPanel7.PerformLayout();
            this.metroPanel6.ResumeLayout(false);
            this.metroPanel6.PerformLayout();
            this.metroTabPage8.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.metroPanel8.ResumeLayout(false);
            this.metroPanel8.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroTabControl metroTabControl1;
        private MetroFramework.Controls.MetroTabPage metroTabPage2;
        private MetroFramework.Controls.MetroTabPage metroTabPage3;
        private MetroFramework.Controls.MetroTabPage metroTabPage4;
        private MetroFramework.Controls.MetroTabPage metroTabPage5;
        private MetroFramework.Controls.MetroTabPage metroTabPage6;
        private MetroFramework.Controls.MetroTabPage metroTabPage7;
        private MetroFramework.Controls.MetroTabPage metroTabPage8;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private MetroFramework.Controls.MetroPanel metroPanel1;
        private MetroFramework.Controls.MetroTile metroTile1;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private MetroFramework.Controls.MetroPanel metroPanel2;
        private System.Windows.Forms.DataGridView dataGridView2;
        private MetroFramework.Controls.MetroTile metroTile2;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private MetroFramework.Controls.MetroPanel metroPanel3;
        private System.Windows.Forms.DataGridView dataGridView3;
        private MetroFramework.Controls.MetroTile metroTile3;
        private MetroFramework.Controls.MetroLabel metroLabel5;
        private MetroFramework.Controls.MetroLabel metroLabel6;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.MonthCalendar monthCalendar2;
        private MetroFramework.Controls.MetroLabel metroLabel9;
        private System.Windows.Forms.MonthCalendar monthCalendar1;
        private MetroFramework.Controls.MetroPanel metroPanel4;
        private System.Windows.Forms.DataGridView dataGridView4;
        private MetroFramework.Controls.MetroTile metroTile4;
        private MetroFramework.Controls.MetroLabel metroLabel7;
        private MetroFramework.Controls.MetroLabel metroLabel8;
        private System.Windows.Forms.TextBox textBox8;
        private MetroFramework.Controls.MetroTile metroTile5;
        private System.Windows.Forms.MonthCalendar monthCalendar4;
        private MetroFramework.Controls.MetroPanel metroPanel5;
        private System.Windows.Forms.DataGridView dataGridView5;
        private MetroFramework.Controls.MetroLabel metroLabel11;
        private MetroFramework.Controls.MetroLabel metroLabel12;
        private System.Windows.Forms.TextBox textBox7;
        private MetroFramework.Controls.MetroLabel metroLabel10;
        private System.Windows.Forms.TextBox textBox9;
        private MetroFramework.Controls.MetroPanel metroPanel6;
        private MetroFramework.Controls.MetroLabel metroLabel16;
        private System.Windows.Forms.TextBox textBox13;
        private MetroFramework.Controls.MetroLabel metroLabel15;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.Label label1;
        private MetroFramework.Controls.MetroLabel metroLabel14;
        private System.Windows.Forms.TextBox textBox11;
        private MetroFramework.Controls.MetroLabel metroLabel13;
        private System.Windows.Forms.TextBox textBox10;
        private MetroFramework.Controls.MetroLabel metroLabel22;
        private System.Windows.Forms.TextBox textBox17;
        private MetroFramework.Controls.MetroLabel metroLabel24;
        private System.Windows.Forms.TextBox textBox18;
        private MetroFramework.Controls.MetroTile metroTile6;
        private MetroFramework.Controls.MetroCheckBox metroCheckBox1;
        private MetroFramework.Controls.MetroLabel metroLabel19;
        private MetroFramework.Controls.MetroLabel metroLabel18;
        private MetroFramework.Controls.MetroComboBox metroComboBox1;
        private MetroFramework.Controls.MetroLabel metroLabel17;
        private System.Windows.Forms.TextBox textBox14;
        private MetroFramework.Controls.MetroPanel metroPanel7;
        private MetroFramework.Controls.MetroTile metroTile7;
        private MetroFramework.Controls.MetroCheckBox metroCheckBox2;
        private MetroFramework.Controls.MetroLabel metroLabel20;
        private MetroFramework.Controls.MetroLabel metroLabel21;
        private MetroFramework.Controls.MetroComboBox metroComboBox2;
        private MetroFramework.Controls.MetroLabel metroLabel23;
        private System.Windows.Forms.TextBox textBox15;
        private MetroFramework.Controls.MetroLabel metroLabel25;
        private System.Windows.Forms.TextBox textBox16;
        private MetroFramework.Controls.MetroLabel metroLabel26;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.Label label2;
        private MetroFramework.Controls.MetroLabel metroLabel27;
        private System.Windows.Forms.TextBox textBox20;
        private MetroFramework.Controls.MetroLabel metroLabel28;
        private System.Windows.Forms.TextBox textBox21;
        private MetroFramework.Controls.MetroLabel metroLabel29;
        private System.Windows.Forms.TextBox textBox22;
        private MetroFramework.Controls.MetroLabel metroLabel30;
        private System.Windows.Forms.TextBox textBox23;
        private MetroFramework.Controls.MetroPanel metroPanel8;
        private MetroFramework.Controls.MetroLabel metroLabel42;
        private System.Windows.Forms.TextBox textBox33;
        private MetroFramework.Controls.MetroLabel metroLabel41;
        private System.Windows.Forms.TextBox textBox32;
        private MetroFramework.Controls.MetroLabel metroLabel40;
        private System.Windows.Forms.TextBox textBox31;
        private MetroFramework.Controls.MetroTile metroTile8;
        private MetroFramework.Controls.MetroCheckBox metroCheckBox3;
        private MetroFramework.Controls.MetroLabel metroLabel31;
        private MetroFramework.Controls.MetroLabel metroLabel32;
        private MetroFramework.Controls.MetroComboBox metroComboBox3;
        private MetroFramework.Controls.MetroLabel metroLabel33;
        private System.Windows.Forms.TextBox textBox24;
        private MetroFramework.Controls.MetroLabel metroLabel34;
        private System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.TextBox textBox26;
        private System.Windows.Forms.Label label3;
        private MetroFramework.Controls.MetroLabel metroLabel36;
        private System.Windows.Forms.TextBox textBox27;
        private MetroFramework.Controls.MetroLabel metroLabel37;
        private MetroFramework.Controls.MetroLabel metroLabel38;
        private System.Windows.Forms.TextBox textBox29;
        private MetroFramework.Controls.MetroLabel metroLabel39;
        private System.Windows.Forms.TextBox textBox30;
        private MetroFramework.Controls.MetroTile metroTile9;
        private MetroFramework.Controls.MetroLabel metroLabel43;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel1;
        private MetroFramework.Controls.MetroTile metroTile10;
        private MetroFramework.Controls.MetroTile metroTile11;
    }
}