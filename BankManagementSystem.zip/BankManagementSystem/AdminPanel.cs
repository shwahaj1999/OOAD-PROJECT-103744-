﻿using MetroFramework.Forms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BankManagementSystem
{
    public partial class AdminPanel :MetroForm
    {
        int ID = 0;
        string LName="";
        public AdminPanel(string LName,int ID)
        {
            this.ID = ID;
            this.LName = LName;
            InitializeComponent();
        }

        private void Admin_Load(object sender, EventArgs e)
        {
            metroLabel43.Text = "(  Welcome : " + LName + "   )";
           
            
        }

        private void metroLabel1_Click(object sender, EventArgs e)
        {

        }

        private void metroPanel6_Paint(object sender, PaintEventArgs e)
        {

        }

        private void metroTabPage1_Click(object sender, EventArgs e)
        {
            
        }

        private void metroTile9_Click(object sender, EventArgs e)
        {
            LoginForm lf = new LoginForm();
            lf.Show();
            this.Hide();
        }

        private void metroTabPage8_Click(object sender, EventArgs e)
        {
           

        }

        private void textBox24_TextChanged(object sender, EventArgs e)
        {
       
        }

        private void metroTile11_Click(object sender, EventArgs e)
        {
            ManageUser mu = new ManageUser();
            string[] getinfo = mu.GetAdminData(ID);
            textBox24.Text = getinfo[1];
            textBox25.Text = getinfo[3];
            textBox26.Text = getinfo[4];
            textBox27.Text = getinfo[5];
            metroComboBox3.Text = getinfo[6];
            textBox29.Text = getinfo[8];
            textBox30.Text = getinfo[9];
            if (getinfo[7]=="True")
            {
                metroCheckBox3.Checked=true;
            }
            else
            {
                metroCheckBox3.Checked = false;
            }
        }
    }
}
