﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System .Data;
using System .Data.OleDb;
namespace BankManagementSystem
{
    class Users
    {
       public static string LName = "";
        int UserId=0;
        string Password = "";
        string Path = "provider=microsoft.ace.oledb.12.0;data source= DataBaseBMS.accdb";

        public Users(int UserId,string Password)
        {
            this.UserId = UserId;
            this.Password = Password;
        }

        public bool VerifyUser() 
        {
                
                OleDbConnection Connect = new OleDbConnection(Path);
                Connect.Open();
                string Query = "select UserName from User where UID=" + UserId + " and Password='" + Password + "'";
                OleDbCommand cmd = new OleDbCommand(Query, Connect);
                OleDbDataReader Reader = cmd.ExecuteReader();
                if (Reader.Read())
                {
                    LName = Reader[1].ToString();
                   
                    return true;

                   
                }
                else
                {
                    Connect.Close();
                    return false;
                    
                }
           
        }
        public bool VerifyAdmin()
        {
           
                OleDbConnection Connect = new OleDbConnection(Path);
                Connect.Open();
                string Query = "select UserName from Admin where AID=" + UserId + " and Password='" + Password + "'";
                OleDbCommand cmd = new OleDbCommand(Query, Connect);
                OleDbDataReader Reader = cmd.ExecuteReader();
                if (Reader.Read())
                {
                    LName=Reader[0].ToString();
                    Connect.Close();
                    return true;
                }
                else
                {
                    Connect.Close();
                    return false;
                }
           
        }




        
    }
}
