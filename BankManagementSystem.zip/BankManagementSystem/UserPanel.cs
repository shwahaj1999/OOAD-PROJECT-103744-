﻿using MetroFramework.Forms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BankManagementSystem
{
    public partial class UserPanel : MetroForm
    {
        string LName = "";
        public UserPanel(string LName )
        {
            this.LName=LName;
            InitializeComponent();
        }

        private void user_Load(object sender, EventArgs e)
        {
            metroLabel1.Text = "(  Welcome : " + LName + "   )";
        }

        private void metroTabPage1_Click(object sender, EventArgs e)
        {
           
        }

        private void metroTile9_Click(object sender, EventArgs e)
        {
            LoginForm lf = new LoginForm();
            lf.Show();
            this.Hide();
        }

        private void metroLabel1_Click(object sender, EventArgs e)
        {

        }
    }
}
