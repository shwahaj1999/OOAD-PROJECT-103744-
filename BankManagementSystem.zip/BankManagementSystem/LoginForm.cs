﻿using MetroFramework.Forms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BankManagementSystem
{
    public partial class LoginForm : MetroForm
    {
        ManageUser mu = new ManageUser();
        public LoginForm()
        {
           
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        
        }


        private void metroTile2_Click(object sender, EventArgs e)
        {

            int UserID = Convert.ToInt32(textBox3.Text);
            string Password = textBox4.Text;
            if (mu.GetUserInfo(UserID, Password) == true)
            {
                MetroFramework.MetroMessageBox.Show(this, "Login Successful As User", "Login", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
              UserPanel us=new UserPanel(Users.LName);
                us.Show();
                this.Hide();
            }
            else
            {
                MetroFramework.MetroMessageBox.Show(this, "Invalid UserID OR Password Please Re-Enter", "Login", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textBox3.Text = null;
                textBox4.Text = null;
            }
        }

        private void metroTile1_Click_1(object sender, EventArgs e)
        {
            try
            {
                int UserID = Convert.ToInt32(textBox1.Text);
                string Password = textBox2.Text.ToUpper();
                if (mu.GetAdminInfo(UserID, Password) == true)
                {
                    MetroFramework.MetroMessageBox.Show(this, "Login Successful As Admin", "Login", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    AdminPanel ad = new AdminPanel(Users.LName, UserID);
                    ad.Show();
                    this.Hide();
                }
                else
                {
                    MetroFramework.MetroMessageBox.Show(this, "Invalid UserID OR Password Please Re-Enter", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    textBox1.Text = null;
                    textBox2.Text = null;
                }
            }
            catch
            {
                MetroFramework.MetroMessageBox.Show(this, "Invalid UserID OR Password Please Re-Enter", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textBox1.Text = null;
                textBox2.Text = null;
            }

           

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
    }
}
