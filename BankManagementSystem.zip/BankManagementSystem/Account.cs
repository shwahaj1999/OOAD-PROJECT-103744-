﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankManagementSystem
{
    class Account
    {
        string UName, Password, Email, CNIC, Contact, Occupation, Address, DateOfBirth, Gender;
        int Age, Income, AvalaibleAmount;
        bool Status;
        public Account(string UName,string Password,string Email,string CNIC,string Contact, int Age ,string Occupation,int Income, int AvalaibleAmount, string Gender,string Address, string DateOfBirth ,bool Status)
        {
            this.UName = UName;
            this.Password = Password;
            this.Email = Email;
            this.CNIC = CNIC;
            this.Contact = Contact;
            this.Age = Age;
            this.Occupation = Occupation;
            this.Income = Income;
            this.AvalaibleAmount = AvalaibleAmount;
            this.Gender = Gender;
            this.Address = Address;
            this.DateOfBirth = DateOfBirth;
            this.Status = Status;


        }
    }
}
