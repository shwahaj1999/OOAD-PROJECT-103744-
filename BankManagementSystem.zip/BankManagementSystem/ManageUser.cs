﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.OleDb;

namespace BankManagementSystem
{
    class ManageUser
    {
        public bool GetUserInfo(int ID, string Password)
        {
            Users us = new Users(ID, Password);

            if (us.VerifyUser() == true)
            {

                return true;


            }
            else
            {
                return false;

            }
        }
        public bool GetAdminInfo(int ID, string Password)
        {
            Users us = new Users(ID, Password);
           
            if (us.VerifyAdmin() == true)
            {
                 
                return true;
               

            }
            else
            {
                return false;
               
            }
        }
        public string[] GetAdminData(int ID)
        { 
            
            string Path = "provider=microsoft.ace.oledb.12.0;data source= DataBaseBMS.accdb";
            OleDbConnection Connection = new OleDbConnection(Path);
            Connection.Open();
            string Query = "Select * From Admin where AID ="+ID;
            OleDbCommand cmd = new OleDbCommand(Query,Connection);
            OleDbDataReader Reader=cmd.ExecuteReader();
            int GetLength = Reader.FieldCount;
            string[] Info = new string[GetLength];
            if (Reader.Read())
            {
                for (int i = 0; i <GetLength; i++)
                {
                    Info[i] = Reader[i].ToString();

                }
            } 
            return Info;

        }

    }
}
